async function loadJSON(path) {
  const res = await fetch(path);
  if (!res.ok) throw new Error(`Failed to load ${path}`);
  return res.json();
}

function formatDate(iso) {
  const d = new Date(iso + "T00:00:00");
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

function renderStub(event) {
  return `
    <a class="stub" href="${event.affiliateUrl}" target="_blank" rel="noopener sponsored">
      <span class="stub-genre">${event.genre}</span>
      <span class="stub-artist">${event.artist}</span>
      <span class="stub-tour">${event.tour}</span>
      <hr class="stub-divider">
      <div class="stub-meta">
        <span class="stub-venue">${event.venue}<br>${event.city}<br>${formatDate(event.date)}</span>
        <span class="stub-price">from $${event.priceFrom}</span>
      </div>
    </a>
  `;
}

function renderPost(post) {
  return `
    <div class="post-item">
      <span class="post-date">${formatDate(post.date)}</span>
      <h3 class="post-title">${post.title}</h3>
      <p class="post-excerpt">${post.excerpt}</p>
    </div>
  `;
}

function buildGenreFilters(events) {
  const genres = ["All", ...new Set(events.map(e => e.genre))];
  const row = document.getElementById("genreFilters");
  row.innerHTML = genres.map((g, i) =>
    `<button class="filter-chip${i === 0 ? " active" : ""}" data-genre="${g}">${g}</button>`
  ).join("");

  row.addEventListener("click", (e) => {
    const btn = e.target.closest(".filter-chip");
    if (!btn) return;
    row.querySelectorAll(".filter-chip").forEach(c => c.classList.remove("active"));
    btn.classList.add("active");
    const genre = btn.dataset.genre;
    const grid = document.getElementById("stubGrid");
    grid.querySelectorAll(".stub").forEach(stub => {
      const match = genre === "All" || stub.querySelector(".stub-genre").textContent === genre;
      stub.style.display = match ? "" : "none";
    });
  });
}

async function init() {
  try {
    const events = await loadJSON("data/events.json");
    const sorted = [...events].sort((a, b) => new Date(a.date) - new Date(b.date));
    document.getElementById("stubGrid").innerHTML = sorted.map(renderStub).join("");
    buildGenreFilters(events);

    const ticker = document.getElementById("tickerTrack");
    ticker.textContent = sorted
      .map(e => `${e.artist} — ${e.city} — ${formatDate(e.date)}`)
      .join("   ★   ") + "   ★   ";
  } catch (err) {
    console.error(err);
    document.getElementById("stubGrid").innerHTML = "<p>Couldn't load shows right now.</p>";
  }

  try {
    const posts = await loadJSON("data/posts.json");
    document.getElementById("postList").innerHTML = posts.map(renderPost).join("");
  } catch (err) {
    console.error(err);
  }
}

init();
